﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon.Game.Framework.Service.Domain
{
    /// <summary>
    /// Domain service to support business logic services
    /// </summary>
    public interface IDomainService : IService
    {
    }
}
