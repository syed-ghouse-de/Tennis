﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon.Game.Framework.Service
{
    /// <summary>
    /// Framework service to support various kinds of services
    /// </summary>
    public interface IService
    {
    }
}
