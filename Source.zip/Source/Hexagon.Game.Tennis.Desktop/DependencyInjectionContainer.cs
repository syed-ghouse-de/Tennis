﻿using Autofac;
using Hexagon.Game.Framework.MVVM.View;
using Hexagon.Game.Tennis.Desktop.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon.Game.Tennis.Desktop
{
    public class DependencyInjectionContainer
    {
        private IContainer _container = null;
        private static DependencyInjectionContainer _instance;

        private DependencyInjectionContainer()
        {            
        }

        public static DependencyInjectionContainer Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new DependencyInjectionContainer();

                return _instance;
            }
        }

        public void RegisterServices()
        {
            var builder = new ContainerBuilder();

            RegisterViews(builder);

            _container = builder.Build();
        }

        public T ResolveNamed<T>(string name)
        {            
            return _container.ResolveNamed<T>(name);
        }

        private void RegisterViews(ContainerBuilder builder)
        {
            foreach (var type in Assembly.GetAssembly(typeof(App)).GetTypes())
            {
                if (type.GetInterfaces().Contains(typeof(IView)))
                {
                    if (type.Name.EndsWith("View", StringComparison.Ordinal))
                        builder.RegisterType(type).Named<IView>(type.Name);                        
                }
            }            
        }
    }
}
