﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon.Game.Tennis.Persistence.Test
{
    class Program
    {
        static void Main(string[] args)
        {
            //MatchPersistenceTest.AddMatch();
            //MatchPersistenceTest.AddMatch();
            //MatchPersistenceTest.AddMatch();

            //MatchPersistenceTest.AddSet();
            //MatchPersistenceTest.GetMatch();
            //MatchPersistenceTest.UpdateSet();
        }
    }
}
